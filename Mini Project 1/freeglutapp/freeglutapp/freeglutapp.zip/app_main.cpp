#include <iostream>
#include <deque>

#if defined WIN32
#include <freeglut.h>
#elif defined __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/freeglut.h>
#endif


using namespace std;

// Some global variables to maintain state

// A point data structure
struct Point {
	// The coordinates of the point
	float x;
	float y;

	// The color of the point
	float r;
	float g;
	float b;

	// A constructor for point
	Point(float x, float y, float r, float g, float b) {
		this->x = x;
		this->y = y;
		this->r = r;
		this->g = g;
		this->b = b;
	}
};

// A "Double Ended QUEue" to store points 
deque<Point> points;

// Variables to store current color, initialize to black
float red = 0.0, green = 0.0, blue = 0.0;

// Store the width and height of the window
int width = 640, height = 640;

//-------------------------------------------------------
// A function to draw the scene
//-------------------------------------------------------
void appDrawScene() {
	// Clear the screen
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set background color to white
	glClearColor(0.0, 0.0, 0.0, 0.0);

	// Set up the transformations stack
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Set the color to the current values of the global vars
	glColor3f(red, green, blue);

	// // Set point size
	glPointSize(6);

	// Draw a point at the bottom-right

	//V Left
	glBegin(GL_POLYGON);
	
	glColor3f(0,1,0.5);

	glVertex2f(-1.0, 0.5);
	glVertex2f(-0.9, 0.5);
	glVertex2f(-0.8, 0);
	glVertex2f(-0.7, 0);
	glVertex2f(-0.9, 0.5);

	glEnd();
	//V Right
	glBegin(GL_POLYGON);
	
	glColor3f(0, 1, 0.5);

	glVertex2f(-0.5, 0.5);
	glVertex2f(-0.6, 0.5);
	glVertex2f(-0.8, 0);
	glVertex2f(-0.7, 0);
	glVertex2f(-0.6, 0.5);

	glEnd();

	glColor3f(0.5, 0.3, 0.5);
	//E Length bar
	glRectf(-0.4f, 0.5f, -0.3f, 0);
	//E top bar
	glRectf(-0.3f, 0.5f, -0.1f, 0.4f);
	//E Mid bar
	glRectf(-0.3f, 0.3f, -0.1f, 0.2f);
	//E Low bar
	glRectf(-0.3f, 0.1f, -0.1f, 0);

	//R Length Bar
	glColor3f(0.3, 0.5, 1);
	glRectf(0, 0, 0.1f, 0.5);
	//R Top bar
	glRectf(0.1f, 0.5f, 0.3f, 0.4f);
	//R Bottom bar
	glRectf(0.1f, 0.3f, 0.3f, 0.2f);
	//R Middle segment
	glRectf(0.2f,0.4f,0.3f,0.3f);
	//R Diagonal
	glBegin(GL_POLYGON);

	glColor3f(0.3, 0.5, 1);

	glVertex2f(0.15, 0.2);
	glVertex2f(0.25, 0.2);
	glVertex2f(0.25, 0);
	glVertex2f(0.35, 0);
	glVertex2f(0.25, 0.2);

	glEnd();

	//O Bottom segment
	glColor3f(1, 0.5, 0.3);
	glRectf(0.4, 0, 0.7, 0.1);
	//O top segment
	glRectf(0.4, 0.4, 0.7, 0.5);
	//O Left segment
	glRectf(0.4, 0.4, 0.5, 0.1);
	//O Right segment
	glRectf(0.6, 0.4, 0.7, 0.1);

	// Draw all the points stored in the double-ended queue
	for (int i = 0; i < points.size(); i++) {

		// Set the vertex color to be whatever we stored in the point
		glColor3f(points[i].r, points[i].g, points[i].b);

		glBegin(GL_POINTS);

		// Draw the vertex in the right position
		glVertex2f(points[i].x, points[i].y);

		glEnd();
	}

	// We have been drawing everything to the back buffer
	// Swap the buffers to see the result of what we drew
	glFlush();
	glutSwapBuffers();
}

//-------------------------------------------------------
// A function to convert window coordinates to scene
// We use it when a mouse event is handled
// Arguments: 	
//	x, y - the coordinates to be updated
//-------------------------------------------------------
void windowToScene(float& x, float& y) {
	x = (2.0f*(x / float(width))) - 1.0f;
	y = 1.0f - (2.0f*(y / float(height)));
}

//-------------------------------------------------------
// A function to handle window resizing
// Called every time the window is resized
// Arguments: 	
//	b    - mouse button that was clicked, left or right
//	s 	 - state, either mouse-up or mouse-down
//	x, y - coordinates of the mouse when click occured
//-------------------------------------------------------
void appReshapeFunc(int w, int h) {
	// Window size has changed
	width = w;
	height = h;

	double scale, center;
	double winXmin, winXmax, winYmin, winYmax;

	// Define x-axis and y-axis range
	const double appXmin = -1.0;
	const double appXmax = 1.0;
	const double appYmin = -1.0;
	const double appYmax = 1.0;

	// Define that OpenGL should use the whole window for rendering
	glViewport(0, 0, w, h);

	// Set up the projection matrix using a orthographic projection that will
	// maintain the aspect ratio of the scene no matter the aspect ratio of
	// the window, and also set the min/max coordinates to be the disered ones
	w = (w == 0) ? 1 : w;
	h = (h == 0) ? 1 : h;

	if ((appXmax - appXmin) / w < (appYmax - appYmin) / h) {
		scale = ((appYmax - appYmin) / h) / ((appXmax - appXmin) / w);
		center = (appXmax + appXmin) / 2;
		winXmin = center - (center - appXmin)*scale;
		winXmax = center + (appXmax - center)*scale;
		winYmin = appYmin;
		winYmax = appYmax;
	}
	else {
		scale = ((appXmax - appXmin) / w) / ((appYmax - appYmin) / h);
		center = (appYmax + appYmin) / 2;
		winYmin = center - (center - appYmin)*scale;
		winYmax = center + (appYmax - center)*scale;
		winXmin = appXmin;
		winXmax = appXmax;
	}

	// Now we use glOrtho to set up our viewing frustum
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(winXmin, winXmax, winYmin, winYmax, -1, 1);
}


//-------------------------------------------------------
// A function to handle keyboard events
// Called every time a key is pressed on the keyboard
// Arguments: 	
//	key  - the key that was pressed
//	x, y - coordinates of the mouse when key is pressed
//-------------------------------------------------------
void appKeyboardFunc(unsigned char key, int x, int y) {
	// Define what should happen for a given key press 
	switch (key) {
		// Space was pressed. Erase all points
	case ' ':
		points.clear();
		break;

		// Escape was pressed. Quit the program
	case 27:
		exit(0);
		break;

		// The "r" key was pressed. Set global color to red
	case 'r':
		red = 1.0;
		green = 0.0;
		blue = 0.0;
		break;

		// The "g" key was pressed. Set global color to green
	case 'g':
		red = 0.0;
		green = 1.0;
		blue = 0.0;
		break;

		// The "b" key was pressed. Set global color to blue
	case 'b':
		red = 0.0;
		green = 0.0;
		blue = 1.0;
		break;

		// The "k" key was pressed. Set global color to black
	case 'k':
		red = 0.0;
		green = 0.0;
		blue = 0.0;
		break;

		// The "w" key was pressed. Set global color to white
	case 'w':
		red = 1.0;
		green = 1.0;
		blue = 1.0;
		break;
	}

	// After all the state changes, redraw the scene
	glutPostRedisplay();
}


int main(int argc, char** argv) {
	// Initialize GLUT
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH);

	// Setup window position, size, and title
	glutInitWindowPosition(20, 60);
	glutInitWindowSize(width, height);
	glutCreateWindow("CSE165 OpenGL Demo");

	// Setup some OpenGL options
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_POINT_SMOOTH);
	glEnable(GL_LINE_SMOOTH);


	// Set callback for drawing the scene
	glutDisplayFunc(appDrawScene);

	// Set callback for resizing th window
	glutReshapeFunc(appReshapeFunc);

	// Set callback to handle keyboad events
	glutKeyboardFunc(appKeyboardFunc);

	// Start the main loop
	glutMainLoop();
}